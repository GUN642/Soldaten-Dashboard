"""
Erzeugt App-Symbol, Startbild und Kopfzeilen-Logo aus
resources/symbol-vorlage.png.

Aufruf:  python3 resources/symbol-erzeugen.py
"""
import os
from PIL import Image

hier = os.path.dirname(os.path.abspath(__file__))
projekt = os.path.dirname(hier) if os.path.basename(hier) == "resources" else hier
res = os.path.join(projekt, "resources")
www = os.path.join(projekt, "www")
VORLAGE = os.path.join(res, "symbol-vorlage.png")

GRUND = (14, 19, 25, 255)     # dunkler Grund, passend zur App


def motiv_laden():
    bild = Image.open(VORLAGE).convert("RGBA")
    kasten = bild.getchannel("A").getbbox()
    return bild.crop(kasten) if kasten else bild


def flaeche(motiv, groesse, anteil, hintergrund=None):
    bild = Image.new("RGBA", (groesse, groesse), hintergrund or (0, 0, 0, 0))
    f = (groesse * anteil) / max(motiv.size)
    neu = motiv.resize((max(1, int(motiv.width * f)), max(1, int(motiv.height * f))),
                       Image.LANCZOS)
    bild.paste(neu, ((groesse - neu.width) // 2, (groesse - neu.height) // 2), neu)
    return bild


if __name__ == "__main__":
    motiv = motiv_laden()
    print("Vorlage:", motiv.size)

    # App-Symbol: das Wappen füllt die Fläche weitgehend aus
    flaeche(motiv, 1024, 1.0).save(os.path.join(res, "icon.png"), "PNG")

    # Adaptives Symbol: kleiner, damit der runde Beschnitt nichts abschneidet
    flaeche(motiv, 1024, 0.66).save(os.path.join(res, "icon-foreground.png"), "PNG")
    Image.new("RGBA", (1024, 1024), GRUND).save(
        os.path.join(res, "icon-background.png"), "PNG")

    # Startbild
    for name in ("splash.png", "splash-dark.png"):
        sp = Image.new("RGBA", (2732, 2732), GRUND)
        k = flaeche(motiv, int(2732 * 0.34), 1.0)
        sp.paste(k, ((2732 - k.width) // 2, (2732 - k.height) // 2), k)
        sp.save(os.path.join(res, name), "PNG")

    # Kopfzeile: nur der obere Teil des Wappens ohne das Schriftband.
    # Bei 28 Bildpunkten Hoehe waere der Schriftzug ohnehin unlesbar, und der
    # Name steht in der Kopfzeile bereits daneben.

    oben = motiv.crop((0, 0, motiv.width, int(motiv.height * 0.73)))
    # Mittig quadratisch fassen
    seite = min(oben.width, oben.height)
    links = (oben.width - seite) // 2
    quadrat = oben.crop((links, 0, links + seite, seite))
    kopf = quadrat.resize((72, 72), Image.LANCZOS)
    kopf.save(os.path.join(www, "logo-header.png"), "PNG", optimize=True)
    kopf.save(os.path.join(www, "logo-header-light.png"), "PNG", optimize=True)

    print("Symbole erzeugt")
