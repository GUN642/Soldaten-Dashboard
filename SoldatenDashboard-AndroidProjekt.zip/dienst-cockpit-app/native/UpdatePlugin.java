package de.gun.dienstcockpit;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;

import androidx.core.content.FileProvider;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Lädt eine APK von einer angegebenen Adresse herunter und öffnet danach den
 * Installationsdialog von Android.
 *
 * Wichtig: Eine App kann sich nicht selbst ohne Zutun aktualisieren. Android
 * verlangt zunächst eine einmalige Freigabe ("Unbekannte Apps installieren")
 * und zeigt bei jeder Installation den Systemdialog, den der Nutzer
 * bestätigen muss.
 */
@CapacitorPlugin(name = "Update")
public class UpdatePlugin extends Plugin {

    /** Prüft, ob diese App APKs installieren darf. */
    @PluginMethod
    public void berechtigungPruefen(PluginCall call) {
        boolean erlaubt = true;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            erlaubt = getContext().getPackageManager().canRequestPackageInstalls();
        }
        JSObject ergebnis = new JSObject();
        ergebnis.put("erlaubt", erlaubt);
        call.resolve(ergebnis);
    }

    /** Öffnet die Systemeinstellung, in der die Freigabe erteilt wird. */
    @PluginMethod
    public void berechtigungOeffnen(PluginCall call) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Intent absicht = new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES);
            absicht.setData(Uri.parse("package:" + getContext().getPackageName()));
            absicht.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(absicht);
        }
        call.resolve();
    }

    /** Lädt die APK herunter und öffnet danach den Installationsdialog. */
    @PluginMethod
    public void herunterladenUndInstallieren(final PluginCall call) {
        final String adresse = call.getString("url");
        if (adresse == null || adresse.length() == 0) {
            call.reject("Keine Adresse angegeben.");
            return;
        }

        new Thread(new Runnable() {
            @Override
            public void run() {
                HttpURLConnection verbindung = null;
                try {
                    File ordner = new File(getContext().getCacheDir(), "updates");
                    if (!ordner.exists()) {
                        ordner.mkdirs();
                    }
                    final File ziel = new File(ordner, "update.apk");

                    URL url = new URL(adresse);
                    verbindung = (HttpURLConnection) url.openConnection();
                    verbindung.setInstanceFollowRedirects(true);
                    verbindung.setConnectTimeout(15000);
                    verbindung.setReadTimeout(15000);
                    verbindung.connect();

                    final int status = verbindung.getResponseCode();
                    if (status != HttpURLConnection.HTTP_OK) {
                        hauptThread(new Runnable() {
                            @Override
                            public void run() {
                                call.reject("Herunterladen fehlgeschlagen (HTTP " + status + ").");
                            }
                        });
                        return;
                    }

                    InputStream eingang = verbindung.getInputStream();
                    FileOutputStream ausgang = new FileOutputStream(ziel);
                    byte[] puffer = new byte[8192];
                    int gelesen;
                    while ((gelesen = eingang.read(puffer)) != -1) {
                        ausgang.write(puffer, 0, gelesen);
                    }
                    ausgang.close();
                    eingang.close();

                    hauptThread(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                installationOeffnen(ziel);
                                JSObject ergebnis = new JSObject();
                                ergebnis.put("erledigt", true);
                                call.resolve(ergebnis);
                            } catch (Exception fehler) {
                                call.reject("Installation konnte nicht gestartet werden: " + fehler.getMessage());
                            }
                        }
                    });

                } catch (final Exception fehler) {
                    hauptThread(new Runnable() {
                        @Override
                        public void run() {
                            call.reject("Herunterladen fehlgeschlagen: " + fehler.getMessage());
                        }
                    });
                } finally {
                    if (verbindung != null) {
                        verbindung.disconnect();
                    }
                }
            }
        }).start();
    }

    /** Wechselt zum Hauptthread, ohne von getActivity() abhängig zu sein —
        die kann nach einem Ausflug in die Systemeinstellungen ungültig sein. */
    private void hauptThread(Runnable aufgabe) {
        new Handler(Looper.getMainLooper()).post(aufgabe);
    }

    private void installationOeffnen(File datei) {
        Context ctx = getContext();
        Uri uri = FileProvider.getUriForFile(ctx, ctx.getPackageName() + ".fileprovider", datei);
        Intent absicht = new Intent(Intent.ACTION_VIEW);
        absicht.setDataAndType(uri, "application/vnd.android.package-archive");
        absicht.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        absicht.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

        // Ohne passende Ziel-App (sehr selten) eine verständliche Meldung
        // statt der rohen Systemausnahme.
        if (absicht.resolveActivity(ctx.getPackageManager()) == null) {
            throw new IllegalStateException(
                "Kein Installationsprogramm auf diesem Gerät gefunden.");
        }
        ctx.startActivity(absicht);
    }
}
