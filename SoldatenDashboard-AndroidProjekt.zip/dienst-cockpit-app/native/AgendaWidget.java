package de.gun.dienstcockpit;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.widget.RemoteViews;

import org.json.JSONObject;

/**
 * Widget für den Startbildschirm: zeigt die Termine und fälligen Aufgaben des
 * Tages in einer scrollbaren Liste.
 *
 * Die Daten kommen aus dem nativen Speicher, den die App über Capacitor
 * Preferences beschreibt (Schlüssel "widget_agenda"). Das Widget braucht daher
 * selbst keinen Zugriff auf Kalender oder Kontakte.
 */
public class AgendaWidget extends AppWidgetProvider {

    private static final String PREFS = "CapacitorStorage";
    private static final String SCHLUESSEL = "widget_agenda";

    @Override
    public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        for (int id : ids) {
            zeichne(context, manager, id);
        }
    }

    /** Von der App aufgerufen, wenn sich die Daten geändert haben. */
    public static void alleAktualisieren(Context context) {
        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        ComponentName name = new ComponentName(context, AgendaWidget.class);
        int[] ids = manager.getAppWidgetIds(name);
        if (ids == null || ids.length == 0) {
            return;
        }
        AgendaWidget widget = new AgendaWidget();
        for (int id : ids) {
            widget.zeichne(context, manager, id);
        }
        manager.notifyAppWidgetViewDataChanged(ids, R.id.liste);
    }

    private void zeichne(Context context, AppWidgetManager manager, int widgetId) {
        RemoteViews ansicht = new RemoteViews(context.getPackageName(), R.layout.agenda_widget);

        JSONObject daten = ladeDaten(context);

        // ---- Darstellung: hell, dunkel oder nach Gerät ----
        String modus = daten != null ? daten.optString("modus", "dunkel") : "dunkel";
        int deckkraft = daten != null ? daten.optInt("deckkraft", 85) : 85;
        boolean hell = "hell".equals(modus);
        if ("system".equals(modus)) {
            int nacht = context.getResources().getConfiguration().uiMode
                    & android.content.res.Configuration.UI_MODE_NIGHT_MASK;
            hell = nacht != android.content.res.Configuration.UI_MODE_NIGHT_YES;
        }

        int grundfarbe = hell ? 0xFFFFFF : 0x0E1319;
        int alpha = Math.max(0, Math.min(100, deckkraft)) * 255 / 100;
        ansicht.setInt(R.id.hintergrund, "setBackgroundColor", (alpha << 24) | grundfarbe);

        int textFarbe = hell ? 0xFF16181D : 0xFFF2F5F9;
        int nebenFarbe = hell ? 0xFF5B6472 : 0xFFAAB4C2;

        // ---- Kopfzeile ----
        String datumText = daten != null ? daten.optString("datum", "") : "";
        String hinweis = daten != null ? daten.optString("hinweis", "") : "";
        int kw = daten != null ? daten.optInt("kw", 0) : 0;

        if (datumText.length() == 0) {
            datumText = "Soldaten Dashboard";
        }
        ansicht.setTextViewText(R.id.datum, datumText);
        ansicht.setTextColor(R.id.datum, textFarbe);

        StringBuilder zusatz = new StringBuilder();
        if (kw > 0) {
            zusatz.append("KW ").append(kw);
        }
        if (hinweis.length() > 0) {
            if (zusatz.length() > 0) {
                zusatz.append(" · ");
            }
            zusatz.append(hinweis);
        }
        ansicht.setTextViewText(R.id.kopfZusatz, zusatz.toString());
        ansicht.setTextColor(R.id.kopfZusatz, nebenFarbe);

        // Antippen der Kopfzeile öffnet die App
        ansicht.setOnClickPendingIntent(R.id.kopfBereich, appOeffnen(context, widgetId));

        // ---- Scrollbare Liste anbinden ----
        Intent dienst = new Intent(context, AgendaWidgetService.class);
        dienst.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId);
        // Eindeutige Adresse, damit Android die Listen mehrerer Widgets unterscheidet
        dienst.setData(Uri.parse(dienst.toUri(Intent.URI_INTENT_SCHEME)));
        ansicht.setRemoteAdapter(R.id.liste, dienst);
        ansicht.setEmptyView(R.id.liste, R.id.leerHinweis);

        // Vorlage für das Antippen einer Zeile
        Intent vorlage = new Intent(context, MainActivity.class);
        vorlage.setAction("de.gun.dienstcockpit.WIDGET_TERMIN");
        vorlage.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        int flaggenVorlage = PendingIntent.FLAG_UPDATE_CURRENT;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
            flaggenVorlage |= PendingIntent.FLAG_MUTABLE;
        }
        ansicht.setPendingIntentTemplate(R.id.liste,
                PendingIntent.getActivity(context, widgetId, vorlage, flaggenVorlage));

        // ---- Hinweis, wenn nichts vorliegt ----
        ansicht.setTextViewText(R.id.leerHinweis,
                daten == null ? "App einmal öffnen" : "Heute nichts eingetragen");
        ansicht.setTextColor(R.id.leerHinweis, nebenFarbe);

        manager.updateAppWidget(widgetId, ansicht);
        manager.notifyAppWidgetViewDataChanged(widgetId, R.id.liste);
    }

    private JSONObject ladeDaten(Context context) {
        try {
            String roh = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                    .getString(SCHLUESSEL, null);
            if (roh == null || roh.length() == 0) {
                return null;
            }
            return new JSONObject(roh);
        } catch (Exception fehler) {
            return null;
        }
    }

    /** Öffnet die App ohne bestimmten Termin. */
    private PendingIntent appOeffnen(Context context, int kennnummer) {
        Intent absicht = new Intent(context, MainActivity.class);
        absicht.setAction(Intent.ACTION_MAIN);
        absicht.addCategory(Intent.CATEGORY_LAUNCHER);
        absicht.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);

        int flaggen = PendingIntent.FLAG_UPDATE_CURRENT;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
            flaggen |= PendingIntent.FLAG_IMMUTABLE;
        }
        return PendingIntent.getActivity(context, kennnummer, absicht, flaggen);
    }
}
