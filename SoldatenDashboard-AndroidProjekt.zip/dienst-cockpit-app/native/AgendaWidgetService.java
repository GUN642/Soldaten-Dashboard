package de.gun.dienstcockpit;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.widget.RemoteViews;
import android.widget.RemoteViewsService;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Füllt die Liste des Widgets. Wird von Android aufgerufen, sobald das Widget
 * gezeichnet oder gescrollt wird.
 */
public class AgendaWidgetService extends RemoteViewsService {

    @Override
    public RemoteViewsFactory onGetViewFactory(Intent absicht) {
        return new AgendaFactory(getApplicationContext());
    }

    static class AgendaFactory implements RemoteViewsService.RemoteViewsFactory {

        private static final String PREFS = "CapacitorStorage";
        private static final String SCHLUESSEL = "widget_agenda";

        private final Context ctx;
        private JSONArray eintraege = new JSONArray();
        private boolean hell = false;

        AgendaFactory(Context context) {
            this.ctx = context;
        }

        @Override
        public void onCreate() {
            laden();
        }

        @Override
        public void onDataSetChanged() {
            laden();
        }

        /** Liest die von der App abgelegte Übersicht. */
        private void laden() {
            try {
                String roh = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                        .getString(SCHLUESSEL, null);
                if (roh == null || roh.length() == 0) {
                    eintraege = new JSONArray();
                    return;
                }
                JSONObject daten = new JSONObject(roh);
                JSONArray liste = daten.optJSONArray("eintraege");
                eintraege = liste != null ? liste : new JSONArray();

                String modus = daten.optString("modus", "dunkel");
                if ("hell".equals(modus)) {
                    hell = true;
                } else if ("system".equals(modus)) {
                    int nacht = ctx.getResources().getConfiguration().uiMode
                            & android.content.res.Configuration.UI_MODE_NIGHT_MASK;
                    hell = nacht != android.content.res.Configuration.UI_MODE_NIGHT_YES;
                } else {
                    hell = false;
                }
            } catch (Exception fehler) {
                eintraege = new JSONArray();
            }
        }

        @Override
        public void onDestroy() {
            eintraege = new JSONArray();
        }

        @Override
        public int getCount() {
            return eintraege.length();
        }

        @Override
        public RemoteViews getViewAt(int stelle) {
            RemoteViews zeile = new RemoteViews(ctx.getPackageName(), R.layout.agenda_zeile);
            JSONObject e = eintraege.optJSONObject(stelle);
            if (e == null) {
                return zeile;
            }

            int textFarbe = hell ? 0xFF16181D : 0xFFF2F5F9;
            int nebenFarbe = hell ? 0xFF5B6472 : 0xFFAAB4C2;

            // Farbmarke des Kalenders
            int farbe = 0xFF8B96A5;
            try {
                String f = e.optString("farbe", "");
                if (f.startsWith("#")) {
                    farbe = Color.parseColor(f);
                }
            } catch (Exception fehler) {
                // Ersatzfarbe verwenden
            }
            zeile.setInt(R.id.zeileFarbe, "setBackgroundColor", farbe);

            // Zeitangabe
            String zeit = e.optString("zeit", "");
            if (zeit.length() == 0) {
                zeit = e.optBoolean("ganztags", false) ? "ganztg." : "—";
            }
            zeile.setTextViewText(R.id.zeileZeit, zeit);
            zeile.setTextColor(R.id.zeileZeit, nebenFarbe);

            // Titel, bei Bedarf mit Ort
            String titel = e.optString("titel", "");
            String ort = e.optString("ort", "");
            if (ort.length() > 0) {
                titel = titel + "  ·  " + ort;
            }
            zeile.setTextViewText(R.id.zeileTitel, titel);
            zeile.setTextColor(R.id.zeileTitel, textFarbe);

            // Antippen: Kennung an das Widget zurückgeben
            Intent fuellung = new Intent();
            fuellung.putExtra("termin", e.optString("kennung", ""));
            zeile.setOnClickFillInIntent(R.id.zeileWurzel, fuellung);

            return zeile;
        }

        @Override
        public RemoteViews getLoadingView() {
            return null;
        }

        @Override
        public int getViewTypeCount() {
            return 1;
        }

        @Override
        public long getItemId(int stelle) {
            return stelle;
        }

        @Override
        public boolean hasStableIds() {
            return true;
        }
    }
}
