package de.gun.dienstcockpit;

import android.content.Context;
import android.database.Cursor;
import android.provider.CalendarContract;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

/**
 * Liest wiederkehrende Termine direkt aus der Android-Kalenderdatenbank
 * (CalendarContract.Events), statt über die von Android selbst ausgerechnete
 * Instanzen-Tabelle zu gehen.
 *
 * Hintergrund: Zu jedem wiederkehrenden Termin legt Android einen
 * Ursprungseintrag mit einer Wiederholungsregel (RRULE) an und berechnet
 * daraus selbst eine zweite, interne Tabelle mit den einzelnen Terminen.
 * Scheitert diese Berechnung für eine bestimmte Regel — etwa bei aus anderen
 * Systemen synchronisierten Terminen (z. B. über FamilyWall eingespielte
 * Apple-Kalendertermine) —, bleibt diese Tabelle für den betroffenen Termin
 * leer, obwohl der Ursprungseintrag weiterhin existiert. Kalender-Module, die
 * nur die bereits berechnete Tabelle lesen, sehen solche Termine dann nicht.
 * Dieses Modul liest stattdessen die Ursprungseinträge direkt; die
 * Wiederholung rechnet die App selbst aus.
 */
@CapacitorPlugin(name = "Wiederholung")
public class WiederholungPlugin extends Plugin {

    @PluginMethod
    public void ursprungsTermine(PluginCall call) {
        Context ctx = getContext();
        JSArray ergebnis = new JSArray();

        String[] projektion = new String[]{
                CalendarContract.Events._ID,
                CalendarContract.Events.CALENDAR_ID,
                CalendarContract.Events.TITLE,
                CalendarContract.Events.DTSTART,
                CalendarContract.Events.DTEND,
                CalendarContract.Events.DURATION,
                CalendarContract.Events.ALL_DAY,
                CalendarContract.Events.RRULE,
                CalendarContract.Events.EVENT_TIMEZONE,
                CalendarContract.Events.EVENT_LOCATION,
                CalendarContract.Events.DESCRIPTION
        };

        // Nur Ursprungstermine mit Wiederholungsregel, keine gelöschten
        String auswahl = CalendarContract.Events.RRULE + " IS NOT NULL AND "
                + CalendarContract.Events.DELETED + " != 1";

        Cursor c = null;
        try {
            c = ctx.getContentResolver().query(
                    CalendarContract.Events.CONTENT_URI, projektion, auswahl, null, null);

            if (c != null) {
                int iId = c.getColumnIndex(CalendarContract.Events._ID);
                int iKal = c.getColumnIndex(CalendarContract.Events.CALENDAR_ID);
                int iTitel = c.getColumnIndex(CalendarContract.Events.TITLE);
                int iStart = c.getColumnIndex(CalendarContract.Events.DTSTART);
                int iEnde = c.getColumnIndex(CalendarContract.Events.DTEND);
                int iDauer = c.getColumnIndex(CalendarContract.Events.DURATION);
                int iGanztag = c.getColumnIndex(CalendarContract.Events.ALL_DAY);
                int iRegel = c.getColumnIndex(CalendarContract.Events.RRULE);
                int iZone = c.getColumnIndex(CalendarContract.Events.EVENT_TIMEZONE);
                int iOrt = c.getColumnIndex(CalendarContract.Events.EVENT_LOCATION);
                int iBeschreibung = c.getColumnIndex(CalendarContract.Events.DESCRIPTION);

                while (c.moveToNext()) {
                    try {
                        long start = c.getLong(iStart);
                        boolean allDay = c.getInt(iGanztag) != 0;

                        long dauerMs;
                        if (!c.isNull(iEnde)) {
                            dauerMs = c.getLong(iEnde) - start;
                        } else {
                            dauerMs = dauerAusIso(c.getString(iDauer), allDay);
                        }
                        if (dauerMs <= 0) {
                            dauerMs = allDay ? 86400000L : 3600000L;
                        }

                        JSObject e = new JSObject();
                        e.put("id", c.getString(iId));
                        e.put("calendarId", c.getString(iKal));
                        e.put("title", c.getString(iTitel) != null ? c.getString(iTitel) : "");
                        e.put("startDate", start);
                        e.put("endDate", start + dauerMs);
                        e.put("isAllDay", allDay);
                        e.put("rrule", c.getString(iRegel));
                        e.put("timezone", c.getString(iZone) != null ? c.getString(iZone) : "");
                        e.put("location", c.getString(iOrt) != null ? c.getString(iOrt) : "");
                        e.put("description", c.getString(iBeschreibung) != null ? c.getString(iBeschreibung) : "");

                        ergebnis.put(e);
                    } catch (Exception einzelFehler) {
                        // einzelnen fehlerhaften Datensatz überspringen, Rest weiterlesen
                    }
                }
            }

            JSObject antwort = new JSObject();
            antwort.put("result", ergebnis);
            call.resolve(antwort);

        } catch (SecurityException fehler) {
            call.reject("Keine Kalenderberechtigung: " + fehler.getMessage());
        } catch (Exception fehler) {
            call.reject("Ursprungstermine konnten nicht gelesen werden: " + fehler.getMessage());
        } finally {
            if (c != null) {
                c.close();
            }
        }
    }

    /**
     * Einfacher Parser für die ISO-8601-Dauer, wie Android sie in der
     * DURATION-Spalte ablegt (z. B. "P1D", "PT2H30M"). Deckt die in der
     * Praxis vorkommenden Fälle ab, keinen vollständigen ISO-8601-Umfang.
     */
    private long dauerAusIso(String iso, boolean allDay) {
        if (iso == null || iso.length() == 0) {
            return allDay ? 86400000L : 3600000L;
        }
        long ms = 0;
        try {
            boolean zeitTeil = false;
            StringBuilder zahl = new StringBuilder();
            for (int i = 0; i < iso.length(); i++) {
                char ch = iso.charAt(i);
                if (ch == 'P') {
                    continue;
                }
                if (ch == 'T') {
                    zeitTeil = true;
                    continue;
                }
                if (Character.isDigit(ch)) {
                    zahl.append(ch);
                    continue;
                }

                long wert = zahl.length() > 0 ? Long.parseLong(zahl.toString()) : 0;
                zahl.setLength(0);

                switch (ch) {
                    case 'W':
                        ms += wert * 7L * 86400000L;
                        break;
                    case 'D':
                        ms += wert * 86400000L;
                        break;
                    case 'H':
                        ms += wert * 3600000L;
                        break;
                    case 'M':
                        ms += zeitTeil ? wert * 60000L : wert * 30L * 86400000L;
                        break;
                    case 'S':
                        ms += wert * 1000L;
                        break;
                    default:
                        break;
                }
            }
        } catch (Exception fehler) {
            return allDay ? 86400000L : 3600000L;
        }
        return ms;
    }
}
